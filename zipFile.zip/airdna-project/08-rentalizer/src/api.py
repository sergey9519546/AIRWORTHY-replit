"""FastAPI application — Rentalizer API."""
import logging
import time
import uuid
from contextlib import asynccontextmanager

import numpy as np
from fastapi import FastAPI, Request, Depends
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.security import APIKeyHeader
from slowapi import Limiter
from slowapi.util import get_remote_address

from .config import settings
from .schemas import (
    EstimateRequest, EstimateResponse, ErrorResponse,
    ConfidenceResponse, CompResponse, MarketResponse,
    HealthResponse, ModelInfoResponse, CreditsResponse,
)
from .exceptions import (
    GeocodingError, OutsideCoverageError, InsufficientCompsError,
    ModelNotReadyError, InvalidInputError,
)
from .validation import validate_input, validate_nyc_bounds
from .geocoder import geocode
from .comp_finder import build_index, find_comps, predict_from_comps, get_market_stats
from .features import build_features, get_borough_from_coords
from .model import load_model, predict, get_model_info, get_feature_columns
from .confidence import compute_confidence

import pandas as pd

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup/shutdown lifecycle."""
    # Startup
    logger.info("Loading model...")
    load_model()

    logger.info("Building comp index...")
    train_df = pd.read_csv(settings.TRAIN_DATA_PATH)
    build_index(train_df)

    logger.info("Ready!")
    yield
    # Shutdown
    logger.info("Shutting down...")


# Rate limiting
limiter = Limiter(key_func=get_remote_address)

app = FastAPI(
    title="Rentalizer",
    description="Short-term rental revenue estimation tool",
    version=settings.VERSION,
    lifespan=lifespan,
)
app.state.limiter = limiter

# Auth
import os
API_KEYS = [k.strip() for k in os.getenv("API_KEYS", "").split(",") if k.strip()]
api_key_header = APIKeyHeader(name="X-API-Key", auto_error=False)

async def verify_api_key(api_key: str = Depends(api_key_header)):
    """Verify API key. Returns None if no keys configured (dev mode)."""
    if not API_KEYS:
        return None  # No auth configured (dev mode)
    if api_key not in API_KEYS:
        raise JSONResponse(status_code=401, content={"error": "unauthorized", "detail": "Invalid or missing API key"})
    return api_key

# Static files and templates
import os


def _meta_blend_alpha() -> float:
    """Load optimized blend alpha from model metadata."""
    try:
        from .model import _meta
        if _meta and "blend_alpha" in _meta:
            return float(_meta["blend_alpha"])
    except Exception:
        pass
    return 0.5  # Default if not found
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
app.mount("/static", StaticFiles(directory=os.path.join(BASE_DIR, "static")), name="static")
templates = Jinja2Templates(directory=os.path.join(BASE_DIR, "templates"))


# --- Exception handlers ---

@app.exception_handler(GeocodingError)
async def geocoding_handler(request, exc):
    return JSONResponse(status_code=422, content={
        "error": "geocoding_failed",
        "detail": str(exc),
        "suggestion": "Try a more specific address (e.g., '350 5th Ave, New York, NY 10118')",
    })

@app.exception_handler(OutsideCoverageError)
async def coverage_handler(request, exc):
    return JSONResponse(status_code=422, content={
        "error": "outside_coverage_area",
        "detail": str(exc),
        "suggestion": "We currently support New York City only.",
    })

@app.exception_handler(InvalidInputError)
async def invalid_input_handler(request, exc):
    return JSONResponse(status_code=422, content={
        "error": "invalid_input",
        "detail": str(exc),
    })

@app.exception_handler(Exception)
async def generic_handler(request, exc):
    logger.exception(f"Unhandled error: {exc}")
    return JSONResponse(status_code=500, content={
        "error": "internal_error",
        "detail": "An unexpected error occurred.",
    })


# --- Routes ---

@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    """Serve the web UI."""
    return templates.TemplateResponse("index.html", {"request": request})


@app.post("/v1/estimate", response_model=EstimateResponse)
@limiter.limit("30/minute")
async def estimate(request: Request, req: EstimateRequest, api_key: str = Depends(verify_api_key)):
    """Single property revenue estimate."""
    request_id = str(uuid.uuid4())[:8]
    start = time.time()

    # 1. Validate input
    warnings = validate_input(req.address, req.bedrooms, req.bathrooms, req.accommodates, req.nightly_rate)

    # 2. Geocode
    t0 = time.time()
    geo = geocode(req.address)
    geocode_ms = int((time.time() - t0) * 1000)

    # 3. NYC bounds check
    validate_nyc_bounds(geo.lat, geo.lng)

    # 4. Find comps
    t0 = time.time()
    comps = find_comps(geo.lat, geo.lng, req.bedrooms, req.accommodates, req.bathrooms)
    comp_ms = int((time.time() - t0) * 1000)

    # 5. Comp-based prediction
    comp_pred, comp_cv = predict_from_comps(comps)

    # 6. Determine borough
    borough = get_borough_from_coords(geo.lat, geo.lng)

    # 7. Build features
    feature_cols = get_feature_columns()
    features = build_features(
        req.nightly_rate, req.bedrooms, req.bathrooms, req.accommodates,
        geo.lat, geo.lng, comps, borough, feature_cols,
        minimum_nights=req.minimum_nights,
        is_superhost=req.is_superhost,
        host_listings_count=req.host_listings_count,
    )

    # 8. Model prediction
    t0 = time.time()
    log_revenue = predict(features)
    model_ms = int((time.time() - t0) * 1000)

    # 9. Smart blend: use comps when model is clearly wrong
    # Model is trained on existing listings. For new listings (no reviews),
    # it under-predicts. Comp-based prediction uses actual revenue from
    # similar properties, so it's more reliable for new listings.
    comp_revenue = float(comp_pred) if comp_pred is not None else None
    model_revenue = float(np.expm1(log_revenue))

    if comp_revenue is not None and comp_revenue > 0 and len(comps) >= 3:
        comp_median = np.median([c.revenue for c in comps])
        ratio = model_revenue / comp_median if comp_median > 0 else 1.0

        if 0.5 <= ratio <= 2.0:
            alpha = 0.7
        elif 0.25 <= ratio <= 4.0:
            alpha = 0.5
        else:
            alpha = 0.3

        final_log_revenue = alpha * log_revenue + (1 - alpha) * np.log1p(comp_revenue)
    elif comp_revenue is not None and comp_revenue > 0:
        # Few comps but some — blend heavily toward comps
        final_log_revenue = 0.3 * log_revenue + 0.7 * np.log1p(comp_revenue)
    else:
        # No comps at all — use market median instead of raw model
        market_revenue = market.get("median_revenue", 79130)
        final_log_revenue = 0.5 * log_revenue + 0.5 * np.log1p(market_revenue)

    annual_revenue = float(np.expm1(final_log_revenue))

    # 10. Confidence
    comp_revenues = [c.revenue for c in comps]
    confidence = compute_confidence(annual_revenue, comp_revenues, len(comps))

    # 11. Market stats
    market = get_market_stats(borough)

    total_ms = int((time.time() - start) * 1000)
    logger.info(
        f"[{request_id}] address={req.address!r} lat={geo.lat:.4f} lng={geo.lng:.4f} "
        f"comps={len(comps)} revenue=${annual_revenue:,.0f} conf={confidence.level} "
        f"geocode={geocode_ms}ms comp={comp_ms}ms model={model_ms}ms total={total_ms}ms"
    )

    # 12. Format response
    return EstimateResponse(
        address=req.address,
        lat=round(geo.lat, 6),
        lng=round(geo.lng, 6),
        annual_revenue=round(annual_revenue, 0),
        confidence=ConfidenceResponse(
            level=confidence.level,
            revenue_lower=confidence.revenue_lower,
            revenue_upper=confidence.revenue_upper,
            cv=confidence.cv,
        ),
        comps=[
            CompResponse(
                distance_km=c.distance_km,
                bedrooms=c.bedrooms,
                revenue=round(c.revenue, 0),
                similarity_score=c.score,
                borough=c.borough,
            )
            for c in comps[:5]
        ],
        market=MarketResponse(
            borough=market.get("borough", borough),
            median_revenue=market.get("median_revenue", 0),
            median_price=market.get("median_price", 0),
            active_listings=market.get("active_listings", 0),
        ),
        disclaimer=settings.DISCLAIMER,
        data_source=settings.DATA_SOURCE,
        model_version=settings.VERSION,
        data_freshness=settings.DATA_FRESHNESS,
    )


@app.post("/v1/batch")
@limiter.limit("5/minute")
async def batch_estimate(request: Request, requests: list[EstimateRequest], api_key: str = Depends(verify_api_key)):
    """Batch estimates (max 20)."""
    if len(requests) > settings.MAX_BATCH:
        return JSONResponse(status_code=413, content={
            "error": "batch_too_large",
            "detail": f"Maximum batch size is {settings.MAX_BATCH}",
        })

    results = []
    for req_item in requests:
        try:
            result = await estimate(request, req_item, api_key)
            results.append(result.model_dump())
        except Exception as e:
            logger.exception(f"Batch item failed: {e}")
            results.append({"error": "estimation_failed", "detail": "Could not estimate this property"})

    return results


@app.get("/v1/health", response_model=HealthResponse)
async def health():
    return HealthResponse(status="ok")


@app.get("/v1/ready")
async def ready():
    from .model import _model as m
    from .comp_finder import _tree as t
    return {"model_loaded": m is not None, "index_loaded": t is not None}


@app.get("/v1/model/info", response_model=ModelInfoResponse)
async def model_info():
    info = get_model_info()
    return ModelInfoResponse(**info)


@app.get("/v1/credits", response_model=CreditsResponse)
async def credits():
    return CreditsResponse(
        data_source="InsideAirbnb",
        license="CC BY 4.0",
        license_url=settings.LICENSE_URL,
        attribution="Data from InsideAirbnb (insideairbnb.com), licensed under CC BY 4.0. "
                    "Data has been processed and transformed for revenue estimation purposes.",
    )
