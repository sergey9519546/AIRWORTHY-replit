#!/usr/bin/env python3
"""
Load InsideAirbnb data into SQLite database.
Handles the actual CSV structure from the NYC dataset.
"""
import csv
import gzip
import os
import sqlite3
import sys

# Paths
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH = os.path.join(BASE_DIR, 'db', 'airbnb.db')
DATA_DIR = os.path.join(BASE_DIR, '..', '06-insideairbnb-data')

def parse_price(price_str):
    """Parse price string like '$113.97' to float."""
    if not price_str:
        return None
    try:
        return float(price_str.replace('$', '').replace(',', ''))
    except ValueError:
        return None

def parse_bool(val):
    """Convert 't'/'f' to 1/0."""
    if val is None or val == '':
        return None
    return 1 if val.lower() == 't' else 0

def parse_int(val):
    """Parse integer, return None if empty."""
    if val is None or val == '':
        return None
    try:
        return int(val)
    except ValueError:
        return None

def parse_float(val):
    """Parse float, return None if empty."""
    if val is None or val == '':
        return None
    try:
        return float(val)
    except ValueError:
        return None

def load_listings(conn, data_dir):
    """Load listings.csv.gz into database."""
    filepath = os.path.join(data_dir, 'listings.csv.gz')
    print(f"Loading listings from {filepath}...")

    # Columns we want to extract (in order matching our schema)
    columns = [
        'id', 'name', 'description', 'host_id', 'host_name', 'host_since',
        'host_is_superhost', 'host_listings_count', 'host_identity_verified',
        'neighbourhood_cleansed', 'neighbourhood_group_cleansed',
        'latitude', 'longitude', 'property_type', 'room_type',
        'accommodates', 'bedrooms', 'beds', 'price',
        'minimum_nights', 'maximum_nights',
        'number_of_reviews', 'number_of_reviews_ltm', 'number_of_reviews_l30d',
        'first_review', 'last_review',
        'review_scores_rating', 'review_scores_accuracy', 'review_scores_cleanliness',
        'review_scores_checkin', 'review_scores_communication',
        'review_scores_location', 'review_scores_value',
        'instant_bookable', 'calculated_host_listings_count',
        'availability_30', 'availability_60', 'availability_90', 'availability_365',
        'estimated_occupancy_l365d', 'estimated_revenue_l365d',
        'amenities'
    ]

    # SQL placeholders
    placeholders = ', '.join(['?' for _ in columns])
    col_names = ', '.join(columns + ['price_numeric'])
    insert_sql = f"INSERT INTO listings ({col_names}) VALUES ({placeholders}, ?)"

    count = 0
    errors = 0

    with gzip.open(filepath, 'rt', encoding='utf-8') as f:
        reader = csv.DictReader(f)

        batch = []
        for row in reader:
            try:
                values = []
                for col in columns:
                    val = row.get(col, '')
                    # Clean string values
                    if val is None or val == '':
                        values.append(None)
                    else:
                        values.append(val)

                # Add parsed price
                price_numeric = parse_price(row.get('price', ''))
                values.append(price_numeric)

                # Convert numeric fields
                for i, col in enumerate(columns):
                    if col in ['id', 'host_id', 'accommodates', 'beds',
                               'minimum_nights', 'maximum_nights',
                               'number_of_reviews', 'number_of_reviews_ltm',
                               'number_of_reviews_l30d',
                               'instant_bookable', 'calculated_host_listings_count',
                               'availability_30', 'availability_60',
                               'availability_90', 'availability_365',
                               'estimated_occupancy_l365d']:
                        values[i] = parse_int(values[i])
                    elif col in ['latitude', 'longitude', 'bedrooms',
                                 'review_scores_rating', 'review_scores_accuracy',
                                 'review_scores_cleanliness', 'review_scores_checkin',
                                 'review_scores_communication', 'review_scores_location',
                                 'review_scores_value', 'estimated_revenue_l365d']:
                        values[i] = parse_float(values[i])
                    elif col in ['host_is_superhost', 'host_identity_verified']:
                        values[i] = parse_bool(values[i])

                batch.append(values)
                count += 1

                # Batch insert every 1000 rows
                if len(batch) >= 1000:
                    conn.executemany(insert_sql, batch)
                    batch = []
                    if count % 10000 == 0:
                        print(f"  ... {count} listings loaded")

            except Exception as e:
                errors += 1
                if errors <= 5:
                    print(f"  Warning: Error processing listing {row.get('id', '?')}: {e}")

        # Insert remaining batch
        if batch:
            conn.executemany(insert_sql, batch)

    conn.commit()
    print(f"Loaded {count} listings ({errors} errors)")
    return count

def load_calendar(conn, data_dir):
    """Load calendar.csv.gz into database."""
    filepath = os.path.join(data_dir, 'calendar.csv.gz')
    print(f"Loading calendar from {filepath}...")

    # Note: This calendar has NO price column!
    # Columns: listing_id, date, available, minimum_nights, maximum_nights
    insert_sql = """INSERT INTO calendar (listing_id, date, available, minimum_nights, maximum_nights)
                    VALUES (?, ?, ?, ?, ?)"""

    count = 0
    batch = []

    with gzip.open(filepath, 'rt', encoding='utf-8') as f:
        reader = csv.DictReader(f)

        for row in reader:
            listing_id = parse_int(row.get('listing_id', ''))
            date = row.get('date', '')
            available = parse_bool(row.get('available', ''))
            min_nights = parse_int(row.get('minimum_nights', ''))
            max_nights = parse_int(row.get('maximum_nights', ''))

            batch.append((listing_id, date, available, min_nights, max_nights))
            count += 1

            if len(batch) >= 10000:
                conn.executemany(insert_sql, batch)
                batch = []
                if count % 500000 == 0:
                    print(f"  ... {count:,} calendar rows loaded")

    if batch:
        conn.executemany(insert_sql, batch)

    conn.commit()
    print(f"Loaded {count:,} calendar rows")
    return count

def load_reviews(conn, data_dir):
    """Load reviews.csv.gz into database."""
    filepath = os.path.join(data_dir, 'reviews.csv.gz')
    print(f"Loading reviews from {filepath}...")

    insert_sql = """INSERT INTO reviews (listing_id, date, reviewer_id, reviewer_name, comments)
                    VALUES (?, ?, ?, ?, ?)"""

    count = 0
    batch = []

    with gzip.open(filepath, 'rt', encoding='utf-8') as f:
        reader = csv.DictReader(f)

        for row in reader:
            listing_id = parse_int(row.get('listing_id', ''))
            date = row.get('date', '')
            reviewer_id = parse_int(row.get('reviewer_id', ''))
            reviewer_name = row.get('reviewer_name', '')
            comments = row.get('comments', '')

            batch.append((listing_id, date, reviewer_id, reviewer_name, comments))
            count += 1

            if len(batch) >= 10000:
                conn.executemany(insert_sql, batch)
                batch = []
                if count % 200000 == 0:
                    print(f"  ... {count:,} reviews loaded")

    if batch:
        conn.executemany(insert_sql, batch)

    conn.commit()
    print(f"Loaded {count:,} reviews")
    return count

def main():
    """Main entry point."""
    # Check if database exists
    if not os.path.exists(DB_PATH):
        print(f"Database not found at {DB_PATH}")
        print("Run create_database.py first!")
        sys.exit(1)

    # Check if data directory exists
    if not os.path.exists(DATA_DIR):
        print(f"Data directory not found: {DATA_DIR}")
        print("Please ensure the InsideAirbnb CSV files are in:")
        print(f"  {DATA_DIR}")
        sys.exit(1)

    # Connect to database
    conn = sqlite3.connect(DB_PATH)

    print("=" * 50)
    print("Loading InsideAirbnb NYC Data")
    print("=" * 50)

    # Load data
    listings_count = load_listings(conn, DATA_DIR)
    calendar_count = load_calendar(conn, DATA_DIR)
    reviews_count = load_reviews(conn, DATA_DIR)

    # Print summary
    print("\n" + "=" * 50)
    print("Loading Complete!")
    print("=" * 50)
    print(f"Listings: {listings_count:,}")
    print(f"Calendar: {calendar_count:,}")
    print(f"Reviews:  {reviews_count:,}")

    # Verify counts
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM listings")
    db_listings = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM calendar")
    db_calendar = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM reviews")
    db_reviews = cursor.fetchone()[0]

    print(f"\nDatabase verification:")
    print(f"  listings in DB: {db_listings:,}")
    print(f"  calendar in DB: {db_calendar:,}")
    print(f"  reviews in DB:  {db_reviews:,}")

    if db_listings != listings_count:
        print(f"  WARNING: Listings count mismatch!")
    if db_calendar != calendar_count:
        print(f"  WARNING: Calendar count mismatch!")
    if db_reviews != reviews_count:
        print(f"  WARNING: Reviews count mismatch!")

    conn.close()
    print("\nDone!")

if __name__ == '__main__':
    main()
